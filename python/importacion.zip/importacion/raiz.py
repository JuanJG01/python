from math import sqrt

numero = 16
raiz_cuadrada = sqrt(numero)

print("La raíz cuadrada de", numero, "es:", raiz_cuadrada)
import math as mt

numero = 25
raiz_cuadrada = mt.sqrt(numero)

print("La raíz cuadrada de", numero, "es:", raiz_cuadrada)

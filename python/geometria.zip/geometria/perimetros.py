def perimetro_cuadrado(lado):
    return 4 * lado

def perimetro_triangulo(lado1, lado2, lado3):
    return lado1 + lado2 + lado3

def perimetro_circulo(radio):
    return 2 * 3.14159 * radio
